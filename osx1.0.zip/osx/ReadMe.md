To start the game give SnakeGame +x and run it 
