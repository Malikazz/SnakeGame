﻿using System;

namespace SnakeGame
{
    class Program
    {
        
        static void Main(string[] args)
        {

           var window = new SimpleWindow();
           window.Run();

           
            
        }
    }
}
